---
name: adaptive-ui
description: Decide quando una risposta funziona meglio come interfaccia interattiva (simulatori con slider, confronti, editor di scene/piani, quiz, dashboard, form) e la costruisce come schema JSON dichiarativo mostrato in chat con il server MCP "adaptive-ui" (render_interactive_ui). Usala quando l'utente vuole simulare, regolare, confrontare, pianificare, modificare o esplorare dati — ad esempio "fammi un simulatore", "voglio provare scenari", "pianifica il reel con le scene", "confronta questi prodotti", "crea un quiz" — e per aggiornare un'interfaccia già mostrata. Non usarla per spiegazioni, definizioni o risposte brevi che stanno meglio in testo.
---

# Adaptive UI

Mostra interfacce interattive nella chat: tu progetti, il renderer le disegna e calcola in locale mentre l'utente muove i controlli. Nessun JavaScript arbitrario: produci uno **schema JSON dichiarativo** e lo passi a `render_interactive_ui`.

Strumenti del server `adaptive-ui`:

| Strumento | Uso |
|---|---|
| `render_interactive_ui({schema})` | valida lo schema e mostra la UI. Se non è valido restituisce gli errori in testo |
| `update_interactive_ui({uiId, schema \| patch, preserveState})` | nuova revisione di una UI già mostrata, conservando i valori dell'utente |
| `get_ui_state({uiId?})` | legge i valori scelti dall'utente e i derivati calcolati |
| `get_ui_reference({topic})` | documentazione: `schema`, `components`, `design`, `examples` |

## 1. Decidi: interfaccia o testo?

Usa un'interfaccia quando l'utente deve **spostare, cambiare, confrontare o modificare** qualcosa:
- simulazioni con parametri (finanza, calcoli, scenari "e se…")
- confronti con criteri pesabili, scelte guidate
- editor di strutture: scene di un video, piani, checklist, menù, calendari
- esplorazione di dati (tabelle, grafici con controlli), dashboard
- quiz, verifiche, esercizi con correzione
- **spiegazioni interattive** (come funziona X, passo per passo): `stepper` + `diagram` + `code` + `quiz`

**Interfaccia ≠ Artifact.** Quando serve un'interfaccia e il server `adaptive-ui` è connesso, usa `render_interactive_ui`: **non** creare un Artifact, un file HTML/React o un widget scritto a mano. Usa un Artifact solo se l'utente lo chiede esplicitamente, se il server non è connesso, o se serve qualcosa che i componenti non coprono (e in quel caso dillo).

Rispondi in testo quando la risposta è una spiegazione, una definizione, un elenco breve, codice o un valore singolo. Se hai dubbi chiediti: "l'utente cambierà un valore e vorrà vedere subito l'effetto?". Se no, testo. Non proporre una UI per decorare.

## 2. Pianifica (3-5 righe, prima dello schema)

Scrivi mentalmente, senza mostrarlo all'utente salvo che serva:
1. **Intento**: che decisione deve prendere l'utente?
2. **Stato**: quali valori cambia lui (con default realistici)?
3. **Derivati**: che cosa si calcola da quei valori (totali, serie per i grafici, avvisi)?
4. **Componenti**: controlli → risultati (kpi, grafico/tabella/timeline) → azioni (reset, "chiedi a Claude").
5. **Layout**: `split` per controlli + risultati, `stack` per flussi lineari, `dashboard` per riepiloghi.

Se la richiesta è ambigua su un punto che cambia molto la UI, fai al massimo una domanda breve; altrimenti scegli default sensati e procedi (l'utente potrà chiedere modifiche).

## 3. Scrivi lo schema

Struttura:

```json
{
  "version": "1", "title": "…", "layout": "split",
  "state":   { "capital": 10000, "rate": 5, "years": 10 },
  "derived": { "final": "capital * (1 + rate/100) ^ years",
               "series": "range(0, years).map(y => {anno: y, valore: round(capital * (1 + rate/100) ^ y)})" },
  "actions": { "reset": {"type": "reset"},
               "ask":   {"type": "ai", "prompt": "Ottimizza questo piano: {{state}}"} },
  "components": [
    { "type": "card", "title": "Parametri", "children": [
        { "type": "slider", "bind": "capital", "label": "Capitale", "min": 1000, "max": 100000, "step": 1000, "format": "currency" },
        { "type": "slider", "bind": "years", "label": "Anni", "min": 1, "max": 40, "unit": "anni" } ] },
    { "type": "stack", "children": [
        { "type": "kpi", "label": "Capitale finale", "value": "final", "format": "currency" },
        { "type": "chart", "chartType": "area", "data": "series", "xKey": "anno", "yKeys": ["valore"], "format": "currency" },
        { "type": "button", "label": "Chiedi a Claude", "action": "ask", "variant": "primary" } ] }
  ]
}
```

Regole essenziali (dettagli in `references/schema-spec.md` e `references/component-registry.md`):
- Ogni proprietà non prevista è un **errore** (schema strict): non inventare campi.
- Gli input fanno `bind` a una chiave di `state` con valore iniziale del tipo giusto. Mai `bind` a un `derived`.
- Tutto ciò che si calcola va in `derived`, scritto con il linguaggio di espressioni (aritmetica, `^`, confronti, ternario, `sum/min/max/round/range/len/map/filter/fmt`, lambda `x => …`). `range(a, b)` include `b`.
- Nei testi usa `{{ espressione }}`; `{{state}}` inserisce lo stato in JSON (utile nelle azioni `ai`).
- Liste modificabili: `list` con `template`, `as`, `addable/removable/reorderable`, `newItem`; dentro il template i campi sono `item.campo` (o l'alias scelto con `as`).
- Per vincoli o avvisi usa `alert` con `visible`, non testo statico.
- Segui `references/design-rules.md` (risultato prima dei dettagli, 8-25 componenti, label brevi, nessun colore fisso).
- Parti dagli esempi in `references/examples/` quando il caso è simile (simulatore finanziario, Reel Planner 30 s con timeline e riordino, confronto prodotti, quiz, lezione interattiva su MCP).

**Spiegazioni interattive e risposte ricche.** Quando l'utente chiede di capire un argomento "in modo interattivo", costruisci una risposta come un articolo breve con **più widget nello stesso messaggio**: testo introduttivo → sezione 1 con widget → sezione 2 con widget → … → quiz finale → chiusura. Chiama `render_interactive_ui` una volta per widget, con testo (titoli `##`, 1-3 frasi) tra una chiamata e l'altra. Componenti pensati per questo: `stepper` (passo per passo con barre di avanzamento) + `diagram` (blocchi e frecce che si illuminano col passo, `active` calcolato da `step`), `code` collapsible con `toggleLabel: "JSON"`, `tabs`, `accordion`, `table`, `quiz`. Usa `frame: "plain"` per i widget inseriti nel testo e le icone (`icon`). Esempi: `mcp-laboratorio`, `mcp-componenti`, `mcp-quiz`.

Lingua dell'interfaccia: quella dell'utente, con accenti corretti.

## 4. Mostra e correggi

1. Chiama `render_interactive_ui` con lo schema (oggetto JSON, non stringa).
2. Se la risposta è un errore (`isError`), **leggi l'elenco**, correggi esattamente quei punti e richiama con lo schema completo. Non chiedere scusa né spiegare all'utente gli errori tecnici: ripara e riprova (massimo 3 tentativi; poi spiega il problema in modo semplice e offri la risposta in testo).
3. **Mai dire che l'interfaccia è pronta o visibile se non hai chiamato `render_interactive_ui` (o `update_interactive_ui`) e il risultato non è stato un successo.** Se lo strumento non è disponibile in questa chat, dillo chiaramente all'utente ("l'estensione Adaptive UI non è attiva in questa chat") invece di descrivere un'interfaccia che non esiste.
4. Dopo il successo scrivi **1-2 frasi** (che cosa può fare con la UI, un'indicazione utile). Non ripetere in testo i numeri o i contenuti già visibili. Non dire mai "non sono riuscito a mostrarla" se lo strumento ha risposto con successo: l'interfaccia è visibile all'utente anche se tu non la vedi.

## 5. Dopo l'uso: leggi lo stato e aggiorna

- Quando l'utente scrive dopo aver usato la UI ("ora aumenta gli anni", "vai con questa versione", "ottimizza"), chiama **`get_ui_state`** per leggere i valori correnti (e i derivati) prima di rispondere. Se un pulsante `ai` ha inviato un messaggio, lo stato è già nel testo.
- Per modificare la UI usa **`update_interactive_ui`** con `preserveState: true`:
  - `patch` (JSON Merge Patch) per cambi piccoli su `state`, `derived`, `actions`, `title`; ricorda che gli **array (`components`) si sostituiscono per intero**.
  - `schema` per ristrutturazioni.
- Per proporre nuovi valori all'utente (es. "adatta a 30 secondi") aggiorna `state` nel `patch` e usa `preserveState: false` solo se vuoi davvero sovrascrivere le sue scelte.

## 6. Ambienti e fallback

- **Claude.ai / Claude Desktop** (connettore MCP): la UI appare in chat.
- **Claude Code** nel terminale non può mostrare MCP Apps: il server crea un'anteprima HTML autonoma e te ne restituisce il percorso `file://`; comunica all'utente di aprirla nel browser (lì i pulsanti `ai` copiano il messaggio negli appunti e `get_ui_state` non vede le modifiche).
- **Server non connesso** (gli strumenti `render_interactive_ui`/`update_interactive_ui` non esistono): non inventare chiamate. Costruisci un equivalente come **Artifact/widget HTML** self-contained (un solo file, JavaScript vanilla, stesse etichette e stessa logica: slider/input che ricalcolano risultati e grafici SVG o tabelle) se l'ambiente li supporta; altrimenti rispondi con una tabella o i passaggi di calcolo in testo e dì all'utente che per la versione interattiva serve collegare il connettore "Adaptive UI".
- Se `get_ui_state` o `update_interactive_ui` rispondono "uiId sconosciuto" il server è stato riavviato: ricrea la UI con `render_interactive_ui`.

## Riferimenti

- `references/schema-spec.md` — struttura, espressioni, azioni, limiti
- `references/component-registry.md` — proprietà di ogni componente
- `references/design-rules.md` — quando e come progettare
- `references/examples/*.json` — schemi completi e validi
