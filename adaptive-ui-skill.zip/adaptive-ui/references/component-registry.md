# Registro dei componenti

Proprietà comuni a tutti: `id?`, `visible?` (espressione), `span?` (1-12). Gli oggetti sono `strict`: non aggiungere proprietà non elencate.
"testo" = stringa che può contenere `{{ espressione }}`. "expr" = espressione. "fmt" = `number | integer | currency | percent | compact | duration | text`.

## Layout

| type | Proprietà | Note |
|---|---|---|
| `stack` | `children`, `gap?` (`none/sm/md/lg`), `align?` | colonna verticale |
| `row` | `children`, `gap?`, `align?`, `wrap?` | riga orizzontale (a capo con `wrap`) |
| `grid` | `children`, `columns?` (1-6, default 2), `gap?` | griglia; su schermi stretti scende a 1 colonna; i figli possono avere `span` |
| `card` | `children`, `title?`, `subtitle?`, `icon?` | riquadro con bordo |
| `tabs` | `tabs`: `[{id, label, children}]`, `bind?` (stringa di stato con l'id della scheda attiva) | schede |
| `divider` | – | linea di separazione |

## Testo

| type | Proprietà | Note |
|---|---|---|
| `heading` | `text`, `level?` (1-3), `icon?` | titolo |
| `text` | `text`, `tone?` (`default/muted/success/warning/danger`), `size?` (`sm/md`) | markdown sicuro: `**grassetto**`, `*corsivo*`, `` `codice` ``, elenchi con `- `, paragrafi. Niente HTML né link |
| `badge` | `text`, `tone?` (`default/success/warning/danger/info`), `icon?` | etichetta compatta |
| `alert` | `text`, `title?`, `tone?` (`info/success/warning/danger`), `icon?` | messaggio evidenziato; usa `visible` per avvisi condizionali |

## Input (tutti con `bind` obbligatorio)

| type | Proprietà | Valore di stato |
|---|---|---|
| `slider` | `bind`, `min`, `max` (numero o expr), `step?`, `label?`, `format?`, `unit?`, `help?` | numero |
| `number` | `bind`, `min?`, `max?`, `step?`, `label?`, `unit?`, `help?` | numero |
| `input` | `bind`, `label?`, `placeholder?`, `maxLength?`, `help?` | stringa |
| `textarea` | `bind`, `label?`, `placeholder?`, `rows?` (2-20), `maxLength?`, `help?` | stringa |
| `select` | `bind`, `options`, `label?`, `help?` | stringa/numero/booleano |
| `toggle` | `bind`, `label?`, `help?` | booleano |
| `segmented` | `bind`, `options`, `label?` | stringa/numero/booleano |

`options`: array di valori semplici (`["a","b"]`, `[15,30,45]`) oppure `{ "value": …, "label": "…" }`.

## Azioni

| type | Proprietà | Note |
|---|---|---|
| `button` | `label` (testo), `action` (nome in `actions`), `variant?` (`primary/secondary/ghost/danger`), `disabled?` (expr), `icon?` | |

## Dati

| type | Proprietà | Note |
|---|---|---|
| `kpi` | `value` (expr), `label?`, `format?`, `digits?`, `hint?` (testo), `tone?` | numero grande con etichetta |
| `chart` | `chartType` (`line/bar/area/pie`), `data` (expr → array di oggetti), `xKey?` (default `x`), `yKeys?` (default `["y"]`), `labels?` (`{chiave: etichetta}`), `title?`, `height?` (120-600), `format?`, `stacked?` | per `pie`: `xKey` = nome della fetta, prima `yKey` = valore. Max 500 punti disegnati |
| `table` | `rows` (expr → array di oggetti), `columns`: `[{key, label?, format?, align?}]`, `title?`, `emptyText?`, `maxRows?` | |
| `progress` | `value` (expr), `max?` (numero/expr, default 100), `label?`, `tone?`, `format?` | barra di avanzamento |

## Liste e media

| type | Proprietà | Note |
|---|---|---|
| `list` | `bind` (array nello stato), `template` (nodi), `as?` (alias, default `item`), `title?`, `itemTitle?` (testo con alias e `index`), `addable?`, `removable?`, `reorderable?`, `addLabel?`, `newItem?` (JSON per i nuovi elementi), `minItems?`, `maxItems?`, `emptyText?` | ripete il `template` per ogni elemento. Nel template usa `"bind": "item.campo"` (con l'alias scelto) e `{{ item.campo }}`/`index` nei testi. Il riordino usa pulsanti su/giù e conserva il contenuto |
| `timeline` | `items` (expr → array), `valueKey`, `labelKey`, `groupKey?`, `target?` (numero/expr), `valueFormat?`, `title?` | segmenti proporzionali al valore (es. durata); colore per gruppo; con `target` mostra il traguardo e segnala lo sforamento |
| `image` | `src` (https:// o data:image/), `alt`, `caption?`, `height?` | immagine; se l'host blocca il dominio mostra il testo alternativo |

## Contenuti ricchi (spiegazioni interattive)

| type | Proprietà | Note |
|---|---|---|
| `stepper` | `steps`: `[{id, title, description?, icon?, children}]`, `bind?` (chiave di stato numerica = indice del passo), `title?`, `progress?` (default true), `backLabel?`, `nextLabel?`, `finishLabel?` | guida a passi con barre di avanzamento, "Passaggio n / N", Indietro/Avanti. Con `bind` puoi far reagire altri componenti al passo (es. `diagram.active`). `description` accetta markdown e `{{ }}` |
| `diagram` | `nodes`: `[{id, label, sublabel?, icon?}]` (2-12), `links?`: `[{from, to, label?}]` (default: catena in ordine), `columns?` (1-6), `active?` (expr → id o array di id), `title?` | schema a blocchi con frecce; i nodi in `active` si illuminano, così come le frecce tra due nodi attivi. Ideale con `stepper` (`active` calcolato da `step`) |
| `code` | `text` (supporta `{{ }}`), `language?`, `title?`, `collapsible?`, `open?`, `toggleLabel?` (es. "JSON" → "Nascondi JSON"), `copyable?` (default true) | blocco di codice/JSON con pulsante Copia e Mostra/Nascondi |
| `quiz` | `questions`: `[{question, options (2-6), answer (indice da 0), explanation?}]`, `title?` | quiz a risposta multipla con correzione immediata, punteggio "Corrette: x/N" e risultato finale. Stato locale |
| `accordion` | `items`: `[{id, title, icon?, children}]`, `multiple?`, `open?` (id della voce aperta o `"none"`) | sezioni comprimibili (FAQ, dettagli) |

Icone (`icon`): brain, plug, server, database, cpu, cloud, globe, laptop, smartphone, user, users, bot, sparkles, zap, search, mail, calendar, file, folder, code, terminal, lock, shield, key, settings, wrench, link, arrow-right, arrow-left, arrow-up-down, check, x, alert, info, lightbulb, rocket, star, heart, play, pause, clock, chart, trending-up, dollar, cart, image, video, music, mic, message, send, book, graduation, target, flag, layers, workflow, network, git-branch, package, refresh, download, upload, eye, eye-off, copy, edit, trash, plus, minus, home, map-pin, phone, camera, film, scissors, palette, list, puzzle.

Un tipo non riconosciuto dal renderer viene mostrato come "componente non supportato" senza rompere il resto della UI.
