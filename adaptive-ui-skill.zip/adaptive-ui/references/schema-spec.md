# Specifica dello schema UI (v1)

Lo schema è un oggetto JSON **dichiarativo**. Il renderer lo valida (Zod `.strict()`: ogni proprietà sconosciuta è un errore) e lo rende con stato reattivo locale. Non esiste JavaScript arbitrario.

## Radice

```json
{
  "version": "1",
  "title": "Titolo breve",
  "description": "opzionale",
  "layout": "stack | dashboard | split",
  "splitAt": 1,
  "frame": "card | plain",
  "state":   { "capital": 10000 },
  "derived": { "final": "capital * 1.05" },
  "actions": { "reset": { "type": "reset" } },
  "components": [ ]
}
```

| Campo | Note |
|---|---|
| `title` | obbligatorio, max 120 caratteri |
| `layout` | `stack` (colonna, default), `dashboard` (griglia responsive, usa `span` 1-12), `split` (due colonne: i primi `splitAt` componenti di primo livello a sinistra, gli altri a destra) |
| `frame` | `card` (default): riquadro con bordo e titolo in alto; `plain`: nessun riquadro né titolo (per widget inseriti nel flusso di una risposta con più widget) |
| `state` | valori iniziali modificabili dall'utente. Chiavi = identificatori (`[A-Za-z_][A-Za-z0-9_]*`). Valori JSON (numeri, stringhe, booleani, array, oggetti). Max ~100 KB |
| `derived` | valori calcolati da espressioni; si ricalcolano a ogni cambio di stato. Possono dipendere da `state` e da altri `derived` (no cicli) |
| `actions` | azioni con nome, richiamate dai `button` |
| `components` | albero di nodi (max 300 nodi, profondità max 12) |

Nomi riservati (non usabili come chiavi di `state`/`derived`/alias): `state`, `derived`, `index`, `true`, `false`, `null`, `undefined` e i nomi delle funzioni (`sum`, `min`, `max`, `round`, `range`, `len`, `map`, `filter`, `fmt`…).

## Nodi

Ogni nodo ha `type` più le proprietà del tipo (vedi `component-registry.md`) e queste proprietà comuni:

- `id` (opzionale, univoco, `[A-Za-z0-9_-]`, max 40)
- `visible` (opzionale): **espressione**; il nodo è mostrato solo se è vera
- `span` (opzionale, 1-12): larghezza in colonne dentro un `grid`/layout `dashboard`

## Binding

`"bind": "capital"` lega un input a una chiave di `state`. Sono ammessi percorsi: `"form.name"`, `"items[2].qty"`. Non si può fare il bind a un valore `derived`. Il tipo del valore iniziale deve essere coerente con il componente (slider/number → numero, toggle → booleano, input/textarea → stringa, list → array).

## Espressioni

Usate in `derived`, `visible`, `kpi.value`, `chart.data`, `table.rows`, `progress.value`, `timeline.items`, `button.disabled`, `min`/`max`/`target` (se stringa) e nelle azioni. Nei **testi** si inseriscono con `{{ espressione }}`: `"Totale: {{ fmt(total, 'currency') }}"`.

- Letterali: numeri (`12`, `1.5`, `1e3`), stringhe (`'ciao'` o `"ciao"`), `true`, `false`, `null`, array `[1, 2]`, oggetti `{x: 1, y: a + b}`.
- Operatori (dalla precedenza minore): `? :` · `??` · `||` · `&&` · `== !=` · `< <= > >=` · `+ -` · `* / %` · unari `- + !` · `^` (potenza, associativo a destra; `-2^2 = -4`) · accesso `a.b`, `a[i]`, chiamate.
- `+` concatena se uno dei due operandi è una stringa. Gli altri operatori aritmetici richiedono numeri (le stringhe numeriche sono convertite).
- Accesso a campo mancante o indice fuori range → `null` (nessun errore). `array.length` e `stringa.length` esistono.
- Lambda: `x => x * 2`, `(x, i) => x + i` (solo come argomento di funzioni/metodi).
- Funzioni:
  `sum(arr[, f])`, `avg(arr[, f])`, `min(...)`, `max(...)` (anche su array), `round(x[, cifre])`, `floor`, `ceil`, `abs`, `sqrt`, `pow(a, b)`, `clamp(x, min, max)`,
  `range(inizio, fine[, passo])` (**fine inclusa**, es. `range(0, 3)` → `[0,1,2,3]`),
  `len(x)`, `count(arr[, f])`, `map(arr, f)`, `filter(arr, f)`, `find(arr, f)`, `sortBy(arr, f)` (crescente; usa `-x` per decrescente), `join(arr[, sep])`, `str(x)`, `num(x)`,
  `fmt(valore, tipo[, cifre])` con tipo `number | integer | currency | percent | compact | duration | text` (`duration` formatta i secondi come `m:ss`).
- Sintassi a metodo equivalente: `arr.map(f)`, `arr.filter(f)`, `arr.find(f)`, `arr.sortBy(f)`, `arr.join(sep)`, `arr.count(f)`, `arr.sum()`, `arr.avg()`, `arr.slice(a, b)`, `arr.includes(x)`; sulle stringhe `toUpperCase`, `toLowerCase`, `trim`, `includes`, `startsWith`, `endsWith`.
- Variabili: chiavi di `state`, chiavi di `derived`, `state` (l'intero stato come oggetto), `derived`, e dentro un `list` l'alias dell'elemento e `index`.
- Vietato: assegnazioni, `function`, template string, accesso a `window`/`process`/`constructor`/`__proto__`, qualunque altra cosa. Limiti: 1000 caratteri per espressione, costo massimo calcolato, `range` max 5000 elementi.

Esempi:

```text
capital * (1 + rate/100) ^ years
range(0, years).map(y => {anno: y, valore: round(capital * (1 + rate/100) ^ y)})
sum(scenes, s => s.duration)
total > target ? 'Troppo lungo' : 'OK'
sortBy(items.filter(p => p.price <= budget), p => -p.score)[0]
```

## Azioni (`actions`)

| `type` | Proprietà | Effetto |
|---|---|---|
| `set` | `target` (percorso di stato), `value` (espressione) | imposta un valore, es. `{"type":"set","target":"rate","value":"7"}` |
| `reset` | `keys?` (elenco di chiavi) | ripristina lo stato iniziale (tutto o solo `keys`) |
| `list-add` | `list`, `item?` (JSON), `at?` (`start`/`end`) | aggiunge un elemento |
| `list-remove` | `list`, `index` (espressione) | rimuove l'elemento |
| `list-move` | `list`, `from`, `to` (espressioni) | sposta un elemento |
| `ai` | `prompt` (testo con `{{ }}`) | invia un messaggio a Claude nella chat; `{{state}}` inserisce lo stato corrente in JSON |
| `tool` | `tool` (`get_ui_state`), `args?` | chiama uno strumento del server (solo quelli consentiti) |
| `sequence` | `steps` (1-20 azioni semplici) | esegue più azioni di fila |

I `button` richiamano un'azione per nome: `{"type":"button","label":"Ripristina","action":"reset"}`. Le azioni non hanno effetti esterni: solo stato locale o un messaggio a Claude.

## Limiti e validazione

Schema max 300 KB · 300 nodi · profondità 12 · 60 `derived` · 60 `actions`. Il server rifiuta lo schema con un elenco di errori leggibili (percorso + causa): correggi e richiama lo strumento. Controlli semantici: bind a chiavi inesistenti, identificatori sconosciuti nelle espressioni, funzioni inesistenti, cicli in `derived`, id duplicati, azioni mancanti, immagini non `https://`/`data:image/`.

## Aggiornare una UI

`update_interactive_ui` accetta `schema` (sostituzione completa) oppure `patch` (JSON Merge Patch: gli oggetti si fondono, gli **array si sostituiscono per intero**, `null` elimina). Con `preserveState: true` (default) i valori dell'utente restano se la chiave esiste ancora con lo stesso tipo.
