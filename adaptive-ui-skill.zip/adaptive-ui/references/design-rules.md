# Regole di progettazione

## Quando serve un'interfaccia

Sì: simulazioni con parametri (finanza, calcoli, scenari), confronti con criteri pesabili, editor di strutture (scene di un video, piani, checklist, menù), esplorazione di dati, quiz e verifiche, wizard con più scelte, dashboard riassuntive.
No: spiegazioni, definizioni, risposte brevi, codice, testo da copiare, dati statici senza decisioni. In dubbio chiediti: "l'utente sposterà, cambierà o confronterà qualcosa?". Se no, rispondi in testo.

## Struttura

1. **Una decisione per UI**: titolo chiaro, controlli a sinistra/in alto, risultati a destra/in basso (`layout: "split"` per simulatori e editor).
2. **Risultato prima dei dettagli**: 2-4 `kpi` nel punto più visibile, poi grafico o tabella, poi note.
3. **Controlli giusti**: `slider` per valori in un intervallo, `number` per valori esatti, `segmented` per 2-5 scelte, `select` per molte scelte, `toggle` per sì/no, `list` per collezioni modificabili.
4. **Defaults sensati**: lo stato iniziale deve già mostrare un risultato significativo e realistico.
5. **Pochi componenti**: 8-25 nodi bastano quasi sempre. Raggruppa con `card`, usa `tabs` solo se ci sono viste davvero distinte.

## Risposte ricche: più widget nello stesso messaggio

Per spiegare un argomento in modo interattivo (come una lezione) **non** mettere tutto in un unico widget. Scrivi la risposta come un articolo breve e inserisci un widget per sezione, chiamando `render_interactive_ui` più volte nello stesso messaggio con testo in mezzo:

1. Un paragrafo introduttivo in testo.
2. Titolo di sezione (`## 1. …`) + una riga di contesto, poi il widget principale: `stepper` + `diagram` per un processo, `tabs` con `code` per categorie di concetti.
3. Sezioni successive: testo breve + widget (accordion, tabella con `table`, grafico).
4. Verso la fine un `quiz` per verificare quanto capito.
5. Chiusura in testo con i punti chiave e un invito a continuare.

Usa `frame: "plain"` per widget che stanno nel flusso del testo e `frame: "card"` (default) per quelli autonomi. Ogni widget ha un solo scopo e titolo breve; il testo attorno spiega, il widget fa provare. Usa `icon` (brain, plug, server, database…) per dare riconoscibilità a card, diagrammi e passaggi.

## Calcoli

- Tutto ciò che si può calcolare va in `derived`, non nello stato. Lo stato contiene solo ciò che l'utente cambia.
- Nomi in inglese o italiano coerenti, brevi, senza spazi (`capital`, `finalValue`, `totale`).
- Per i grafici crea una `derived` che restituisce un array di oggetti con chiavi leggibili (`{anno, valore}`) e usa `xKey`/`yKeys`.
- Formatta con `format` (`currency`, `percent`, `duration`…) invece di concatenare stringhe.
- Evita di dividere per zero: usa un ternario (`x > 0 ? y / x : 0`).

## Testi e lingua

Interfaccia nella lingua dell'utente, etichette brevi (2-4 parole), unità accanto al valore (`unit`), spiegazioni nel campo `help`. Niente emoji decorative. Avvisi con `alert` e `visible`, un solo concetto per avviso.

## Interazione con Claude

- Il pulsante `ai` serve per ciò che richiede il modello (ottimizzare, riscrivere, spiegare): includi nel `prompt` solo il contesto necessario più `{{state}}`.
- Dopo che l'utente ha usato la UI: chiama `get_ui_state` per leggere i valori e `update_interactive_ui` (con `preserveState`) per modificare, invece di ricreare tutto.
- Dopo il rendering scrivi al massimo 1-2 frasi: la UI parla da sola, non ripetere i numeri.

## Accessibilità e tema

Ogni input ha un'etichetta (`label`). Non codificare colori: il renderer usa i colori dell'host (chiaro/scuro). Usa `tone` per il significato (successo/avviso/errore), non il solo colore: aggiungi anche il testo.

## Errori frequenti

- `bind` a una chiave non presente in `state` o a un `derived`.
- Dimenticare `as` e usare un alias diverso da `item` nel template di una `list`.
- `range(0, n)` include `n` (fine inclusa).
- Proprietà inventate (`color`, `onChange`, `style`): lo schema è strict, vengono rifiutate.
- Valori `state` con tipo diverso dal componente (stringa per uno slider).
